//#ifdef __cplusplus
extern "C" (
//#endif
int fn(int argc, char** argv);
//#ifdef __cplusplus
)
//#endif
