#include "fn.h"

int fn(int argc, char** argv) {
	return argc+1;
}
