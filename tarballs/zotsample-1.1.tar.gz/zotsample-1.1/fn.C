#include "fn.h"

extern "C" int fn(int argc, char** argv) {
	return argc+1;
}
